﻿import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService, UserService } from '../../../_services/index';
import { CreateteamComponent } from '../createteam.component';

@Component({
    moduleId: module.id,
    selector: '<app-collage>',
    templateUrl: 'collage.html'

})

export class CreateteamCollege {
    createteam: CreateteamComponent; 
    model: any = {};
    currentUser: Object;
    sportstabs: any[];
    class:string; 
    html:string;
    footballTabs = [{'name':'college', 'value':'College'}, 
        {'name':'highschool','value':'High School'}, 
        {'name':'middleschool','value':'Middle School'}, 
        {'name':'elementary','value':'Elementary'},
        {'name':'league','value':'League'}];

    basketballTabs = [{'name':'btcollege', 'value':'College'}, 
        {'name':'bthighschool','value':'High School'}, 
        {'name':'btmiddleschool','value':'Middle School'}, 
        {'name':'btelementary','value':'Elementary'},
        {'name':'btleague','value':'League'}];


    constructor(
        private router: Router,
        private userService: UserService, 
        private alertService: AlertService) { 
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.sportstabs = this.currentUser['field_sport_you_coach'];
           
      }

    public onclicktab(name:string){
        this.class = name;
        console.log(name);
       
    }
    
    createteam_Submit() {
        console.log(this.model);
    }

    

    

    
}
