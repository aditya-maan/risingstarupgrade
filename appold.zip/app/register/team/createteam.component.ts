﻿import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService, UserService } from '../../_services/index';
import { CreateteamCollege } from '../team/College/College.component';


@Component({
    moduleId: module.id,
    templateUrl: 'createteam.html',
    providers: [CreateteamCollege]
})

export class CreateteamComponent {
    model: any = {};
    currentUser: Object;
    sportstabs: any[];
    tabindex:string; 
    html:string;
    
    
    footballTabs = [{'name':'college', 'value':'College', 'model':""}, 
        {'name':'highschool','value':'High School'}, 
        {'name':'middleschool','value':'Middle School'}, 
        {'name':'elementary','value':'Elementary'},
        {'name':'league','value':'League'}];

    basketballTabs = [{'name':'btcollege', 'value':'College'}, 
        {'name':'bthighschool','value':'High School'}, 
        {'name':'btmiddleschool','value':'Middle School'}, 
        {'name':'btelementary','value':'Elementary'},
        {'name':'btleague','value':'League'}];


    constructor(
        private router: Router, private CreateteamCollege: CreateteamCollege,
        private userService: UserService,
        private alertService: AlertService) { 
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.sportstabs = this.currentUser['field_sport_you_coach'];
        
           
      }

    public onclicktab(name:string){
        this.tabindex = name['index'];
        console.log(this.tabindex);
    }
    
    createteam_Submit() {
        //this.CreateteamCollege.createteam_Submit();
        
//        this.model =this.CreateteamCollege.createteam_Submit();
//        console.log(this.model);
        //console.log(this.myData.name);
    }
}

 