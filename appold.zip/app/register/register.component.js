"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var index_1 = require("../_services/index");
var RegisterComponent = (function () {
    function RegisterComponent(router, userService, alertService) {
        var _this = this;
        this.router = router;
        this.userService = userService;
        this.alertService = alertService;
        this.model = {};
        this.insschoolslist = {};
        this.loading = false;
        this.Tabs = [{ 'name': 'athlete', 'value': 'Athlete' },
            { 'name': 'coach', 'value': 'Coach' },
            { 'name': 'admin_teacher', 'value': 'Admin/Teacher' },
            { 'name': 'fan', 'value': 'Fan' },
            { 'name': 'collegiate_affiliations', 'value': 'Scout(no collegiate affiliations)' },
            { 'name': 'parent_relative', 'value': 'Parent/Relative' }];
        this.data = {};
        this.email = {};
        this.password = {};
        this.insschools = [{ ins: '' }, { ins: '' }, { ins: '' }];
        this.childnames = [{ ins: "" }];
        this.relativenames = [{ 'rfname': "" }];
        this.scouts = [{ player: '' }, { player: '' }, { player: '' }, { player: '' }];
        this.states = [
            "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"
        ];
        this.coachinglevel = ["D1-A", "D1-AA", "D2", "D3", "NAIA", "JUCO", "High School", "Middle School", "AAU", "League"];
        this.Football = ["Head coach", "Offensive coordinator", "Defensive coordinator", "Special teams coach", "Quarterbacks coach", "Running backs coach", "Wide receiver coach", "Offensive line coach", "Defensive line coach", "Linebackers coach", "Secondary coach"];
        this.btposstaff = ["Head Coach", "Assistant Coach"];
        this.OffPosition = ["QB", "HB", "FB", "TE", "WR", "LT", "LG", "C", "RG", "RT"];
        this.DefPosition = ["CB", "FS", "SS", "OLB", "ILB", "DE", "DT"];
        this.TemPosition = ["K", "P", "LOS"];
        this.PriPosition = ["Offense", "Defense", "Special Teams"];
        this.SecPosition = ["Offense", "Defense"];
        this.BaskPosition = ["PG", "SG", "SF", "PF", "C"];
        console.log('res');
        this.userService.getpostdata('http://m6risingstarsbxyhxef47n.devcloud.acquia-sites.com/schoollist-rest')
            .subscribe(function (data) {
            _this.sclist = data;
        });
    }
    RegisterComponent.prototype.register = function () {
        var _this = this;
        var usersData;
        //var usersData = [];
        for (var i = 0; i < this.scouts.length; i++) {
            usersData.push(this.scouts[i]['player']);
        }
        this.model.scouts = usersData;
        var usersData2;
        //var usersData2 = [];
        for (var i = 0; i < this.childnames.length; i++) {
            usersData2.push(this.childnames[i]['childf'] + ' ' + this.childnames[i]['childl']);
        }
        this.model.childnames = usersData2;
        var usersData3;
        //var usersData3 = [];
        for (var i = 0; i < this.relativenames.length; i++) {
            usersData3.push(this.relativenames[i]['rfname'] + ' ' + this.childnames[i]['rlname']);
        }
        this.model.relativenames = usersData3;
        var usersData4;
        //var usersData4 = [];
        for (var i = 0; i < this.insschools.length; i++) {
            usersData4.push(this.insschools[i]['school']);
        }
        this.model.school = usersData4;
        this.loading = true;
        this.userService.create(this.model)
            .subscribe(function (data) {
            _this.alertService.success('Registration successful', true);
            _this.router.navigate(['/login']);
        }, function (error) {
            _this.alertService.error(error);
            _this.loading = false;
        });
    };
    RegisterComponent.prototype.onclicktab = function (name) {
        this.class = name;
    };
    RegisterComponent.prototype.addSchoolName = function () {
        var dataObj = { ins: '' };
        this.insschools.push(dataObj);
    };
    RegisterComponent.prototype.addScoutedPlayer = function () {
        var dataObj = { player: '' };
        this.scouts.push(dataObj);
    };
    RegisterComponent.prototype.addchildname = function () {
        var dataObj = { ins: '' };
        this.childnames.push(dataObj);
    };
    RegisterComponent.prototype.addrelativename = function () {
        var dataObjrel = { rfname: '' };
        this.relativenames.push(dataObjrel);
    };
    RegisterComponent.prototype.onChange = function (name) {
        this.classteach = name;
    };
    RegisterComponent.prototype.onChangecoach = function (name) {
        this.classcoach = name;
    };
    RegisterComponent.prototype.onChangecoachstaff = function (name) {
        this.classcoachstaff = name;
    };
    RegisterComponent.prototype.onChangeathlete = function (name) {
        this.classcoachathlete = name;
    };
    return RegisterComponent;
}());
RegisterComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'register.component.html'
    }),
    __metadata("design:paramtypes", [router_1.Router,
        index_1.UserService,
        index_1.AlertService])
], RegisterComponent);
exports.RegisterComponent = RegisterComponent;
//# sourceMappingURL=register.component.js.map