"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./register.component"));
__export(require("./team/createteam.component"));
__export(require("./team/College/College.component"));
//# sourceMappingURL=index.js.map