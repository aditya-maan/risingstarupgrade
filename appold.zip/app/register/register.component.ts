﻿import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { AlertService, UserService } from '../_services/index';

@Component({
    moduleId: module.id,
    templateUrl: 'register.component.html'
})

export class RegisterComponent {
    model: any = {};
    insschoolslist: any = {};

    loading = false;
     Tabs = [{'name':'athlete', 'value':'Athlete'}, 
        {'name':'coach','value':'Coach'}, 
        {'name':'admin_teacher','value':'Admin/Teacher'}, 
        {'name':'fan','value':'Fan'},
        {'name':'collegiate_affiliations','value':'Scout(no collegiate affiliations)'},
        {'name':'parent_relative','value':'Parent/Relative'}];
    classteach: string; 
    class: string; 
    classcoach: string;
    data = {};
    email = {};
    password = {};
    sclist: any[];
    selected: any[];

    insschools = [ { ins: '' }, { ins: '' }, { ins: '' }] 
    childnames = [ {ins:""}]; 
    relativenames = [{'rfname':""}]; 
    scouts = [{ player: '' },{ player: '' },{ player: '' },{ player: '' }];     
    states = [
            "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"       
            ];    
    
    coachinglevel = ["D1-A","D1-AA","D2","D3","NAIA","JUCO","High School","Middle School","AAU","League"]; 
    Football = ["Head coach","Offensive coordinator","Defensive coordinator","Special teams coach","Quarterbacks coach","Running backs coach","Wide receiver coach","Offensive line coach","Defensive line coach","Linebackers coach","Secondary coach"];    
    btposstaff = ["Head Coach","Assistant Coach"];

    OffPosition = ["QB","HB","FB","TE","WR","LT","LG","C","RG","RT"]; 
    DefPosition = ["CB","FS","SS","OLB","ILB","DE","DT"];   
    TemPosition = ["K","P","LOS"];
    PriPosition = ["Offense","Defense","Special Teams"];  
    SecPosition = ["Offense","Defense"];
    BaskPosition = ["PG","SG","SF", "PF", "C"];

    constructor(
        private router: Router,
        private userService: UserService,
        private alertService: AlertService) { 
        console.log('res');
            this.userService.getpostdata('http://m6risingstarsbxyhxef47n.devcloud.acquia-sites.com/schoollist-rest')
              .subscribe(data => {
                this.sclist = data;
          });
      }

    register() {
        
        var usersData:any[];
        //var usersData = [];
        for (let i = 0; i < this.scouts.length; i++) {
             usersData.push(this.scouts[i]['player']);
        }
        this.model.scouts = usersData;
        var usersData2:any[];
        //var usersData2 = [];
        for (let i = 0; i < this.childnames.length; i++) {
             usersData2.push(this.childnames[i]['childf']+' '+this.childnames[i]['childl']);
             
        }
        this.model.childnames = usersData2;
        var usersData3: any[];
        //var usersData3 = [];
        for (let i = 0; i < this.relativenames.length; i++) {
             usersData3.push(this.relativenames[i]['rfname']+' '+this.childnames[i]['rlname']);
        }
        this.model.relativenames = usersData3;
        var usersData4: any[];
        //var usersData4 = [];
        for (let i = 0; i < this.insschools.length; i++) {
             usersData4.push(this.insschools[i]['school']);
        }
        this.model.school = usersData4;
        this.loading = true;
         this.userService.create(this.model)
            .subscribe(
                data => {
                    this.alertService.success('Registration successful', true);
                    this.router.navigate(['/login']);
                },
                error => {
                    this.alertService.error(error);
                    this.loading = false;
                }); 
    }

    public onclicktab(name:string){
        this.class = name;
       
    }
    public addSchoolName(){ 
        var dataObj =  {ins:''};
         this.insschools.push(dataObj); 
    } 
    addScoutedPlayer(){        
        var dataObj = {player:''};
        this.scouts.push(dataObj);
    } 
    public addchildname(){
        var dataObj =  {ins:''};
        this.childnames.push(dataObj); 
    } 
    public addrelativename(){
        var dataObjrel = {rfname:''}
         this.relativenames.push(dataObjrel); 
    }
    public onChange(name:string){
        this.classteach = name;
    } 
    public onChangecoach(name:string){
        this.classcoach = name;
    }
    classcoachstaff:string;
    public onChangecoachstaff(name:string){
        this.classcoachstaff = name;
    }
    classcoachathlete: string;
    public onChangeathlete(name:string){
        this.classcoachathlete = name;
    }

    
}
