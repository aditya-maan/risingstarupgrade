﻿export * from './register.component';
export * from './team/createteam.component';
export * from './team/College/College.component';