"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
//import { User } from '../_models/index';
//import { UserService } from '../_services/index';
var router_1 = require("@angular/router");
//import { ProfileBannerComponent }  from './profile_banner/profile_banner.component';
var ProfileComponent = (function () {
    function ProfileComponent(router, route) {
        //console.log('---'+localStorage.getItem('currentUser'));
        this.router = router;
        this.route = route;
        if (localStorage.getItem('currentUser')) {
            this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
            this.currentUsername();
        }
        else {
            this.router.navigate(['/login']);
        }
    }
    ProfileComponent.prototype.currentUsername = function () {
        if (this.currentUser) {
            if (this.currentUser['field_first_name'][0]['value']) {
                var fname = this.currentUser['field_first_name'][0]['value'];
            }
            if (this.currentUser['field_middle_name'][0]['value']) {
                var mname = this.currentUser['field_middle_name'][0]['value'];
            }
            if (this.currentUser['field_last_name'][0]['value']) {
                var lname = this.currentUser['field_last_name'][0]['value'];
            }
            this.userName = fname + ' ' + mname + ' ' + lname;
        }
    };
    return ProfileComponent;
}());
ProfileComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'app.profile.html',
    }),
    core_1.Injectable(),
    __metadata("design:paramtypes", [router_1.Router, router_1.ActivatedRoute])
], ProfileComponent);
exports.ProfileComponent = ProfileComponent;
//# sourceMappingURL=profile.component.js.map