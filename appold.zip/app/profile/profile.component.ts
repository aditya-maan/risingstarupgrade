import { Component, Injectable} from '@angular/core';
//import { User } from '../_models/index';
//import { UserService } from '../_services/index';
import { Router, ActivatedRoute} from '@angular/router';

//import { ProfileBannerComponent }  from './profile_banner/profile_banner.component';

@Component({
  moduleId: module.id,
  templateUrl: 'app.profile.html',
})

@Injectable()
export class ProfileComponent {
  
    currentUser: Object;
    userName: string; 
   

    constructor( private router: Router,  private route: ActivatedRoute
        ) { 
        //console.log('---'+localStorage.getItem('currentUser'));

             if (localStorage.getItem('currentUser')) {
            this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
            this.currentUsername()
            //return true;
            } else { 
                this.router.navigate(['/login']);
            }
          }

    public currentUsername(){
            if(this.currentUser) {
            if(this.currentUser['field_first_name'][0]['value']){
              var fname = this.currentUser['field_first_name'][0]['value'];
            }
            if(this.currentUser['field_middle_name'][0]['value']){
              var mname =   this.currentUser['field_middle_name'][0]['value'];
            }
            if(this.currentUser['field_last_name'][0]['value']){
              var lname =   this.currentUser['field_last_name'][0]['value'];
            }
            this.userName = fname+' '+mname+' '+lname;
            }


        
        
    }      


          
}
        

 

