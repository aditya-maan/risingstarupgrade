import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: 'app/home/footer/app.footer.html',
})

export class FooterComponent {
  values = '';
 

}

